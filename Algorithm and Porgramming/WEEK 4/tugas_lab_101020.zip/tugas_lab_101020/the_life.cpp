#include<stdio.>

int main(){
	int num;
	
	while(1){
		scanf("%d", &sum);
		if (num == 42){
			break;
		}
		
		int sum = 0;
		sum+=num;
		printf("%d\n", sum);
	}
	
	return 0;
}
